# Imágenes de productos con Supabase Storage

El alta (POST) y la edición (PUT) envían un multipart a `/api/productos`: parte `producto` (JSON con datos, variantes, precios y la lista `imagenes`, donde cada imagen dice su color y la posición de su archivo) y parte `imagenes` (uno o varios archivos). El backend valida JPEG, PNG o WebP, máximo 5 MiB por archivo y 10 archivos por petición (52 MB en total), y genera un nombre UUID. PostgreSQL conserva solamente la URL pública en `imagen_producto.url_imagen` y el color en `imagen_producto.color_id`.

## Configurar una sola vez

1. En tu proyecto Supabase, abre **Storage → New bucket**.
2. Nombre: **productos**. Activa **Public bucket** porque las fotos del catálogo son públicas.
3. Configura límite de archivo **5 MB** y tipos permitidos `image/jpeg`, `image/png`, `image/webp`. No agregues políticas de escritura pública: las subidas pasan por el backend autenticado.
4. En **Settings → API Keys**, copia una clave **secret** exclusivamente al backend. También se admite la antigua `service_role`. No uses la clave publishable para esta operación.
5. Configura las variables de entorno del proceso que inicia la API y reiníciala:

```dotenv
SUPABASE_SECRET_KEY=tu_clave_secreta
SUPABASE_STORAGE_BUCKET=productos
```

La URL del proyecto reutiliza `supabase.url`, ya configurada para la autenticación. No es la URL JDBC ni la dirección del pooler.

En NetBeans puedes configurar el entorno del proceso; alternativamente, en tu `application.properties` local ignorado por Git:

```properties
supabase.secret-key=tu_clave_secreta
supabase.storage-bucket=productos
```

Nunca pongas la clave secret/service_role en variables `VITE_`, en el frontend o en archivos versionados. No se requiere una migración adicional de tablas para Storage.

## Probar

Inicia backend y frontend. Entra con ADMIN o EMPLEADO, abre Nuevo producto, elige las fotos de cada color, completa variantes y precios y guarda. Debe devolver 201, mostrar el producto y crear un objeto en `productos/catalogo/`. La BD guarda su URL, no bytes ni rutas locales del equipo.

## Capas y errores

Negocio define `IAlmacenImagenes` y coordina validación, subida y persistencia. Infraestructura implementa la comunicación HTTP con Supabase. API recibe multipart. Persistencia sigue guardando entidades y URLs mediante DAO.

Los datos inválidos, los colores sin imagen y las claves ya existentes se rechazan antes de subir. Si falla la subida de un archivo, se retiran los que ya se habían subido. Si la transacción se revierte, se intentan retirar los archivos. PostgreSQL y Storage no comparten una transacción: si falla esa limpieza o el resultado del commit es desconocido, se registra el caso para reconciliación. En este último caso se conserva la imagen para evitar borrar un archivo que podría estar referenciado. El POST JSON previo sigue disponible para clientes que ya tienen URLs.

Al editar, las imágenes que se quitan se borran de Storage **después del commit** y solo si (1) ningún otro producto usa la misma URL y (2) la subió el backend (`catalogo/<uuid>.<ext>`); las de otras carpetas del bucket (por ejemplo `flycaps/…`) o de otros sitios nunca se borran. Si el borrado falla, se registra para limpiarlo a mano; el producto ya quedó guardado.

La baja de productos conserva su comportamiento anterior; no se ha añadido eliminación remota de imágenes a ese flujo pendiente.

La implementación se verifica con pruebas HTTP simuladas; la configuración del bucket y una subida real requieren tu proyecto Supabase.

Documentación oficial: [claves API](https://supabase.com/docs/guides/getting-started/api-keys), [subidas](https://supabase.com/docs/guides/storage/uploads/standard-uploads), [URLs públicas](https://supabase.com/docs/guides/storage/serving/downloads).
