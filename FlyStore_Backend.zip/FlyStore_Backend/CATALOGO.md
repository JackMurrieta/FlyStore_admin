# Catálogo administrativo

Implementación de los cuatro diagramas proporcionados, distribuida en los proyectos existentes. Se conserva la autenticación, los DAO anteriores y las entidades previas. Se retiraron UsuarioBO, IUsuarioBO, AuthMapper y ClienteMapper, añadidos durante la refactorización y ausentes de estos diagramas; su comportamiento de autenticación se conserva en las clases anteriores.

## Clases del catálogo

- Persistencia: ProductoDAO, CategoriaDAO, SubcategoriaDAO, MarcaDAO, TallaDAO, DetallePedidoDAO y sus seis interfaces. Usan EntityManager, sin añadir repositorios o servicios no diagramados.
- Negocio: ProductoBO/IProductoBO, CatalogoBO/ICatalogoBO, ProductoMapper y CatalogoMapper.
- DTOs: ProductoCatalogoDTO, CrearProductoDTO, VarianteDTO, PrecioProductoDTO, CatalogoItemDTO, FiltrosDisponiblesDTO, TallaDTO y ResultadoBajaDTO.
- API: ProductoController y CatalogoController.

Los identificadores de entidades y métodos DAO son Long. Los BO públicos y DTOs reciben o devuelven String. Los importes usan BigDecimal. Las tallas y colores del alta son nombres; se resuelven contra los registros existentes sin crear catálogos implícitamente. Las tallas deben pertenecer a la categoría seleccionada. Cada imagen se liga a un color de las variantes (imagen_producto.color_id) y cada color debe tener al menos una imagen.

## Migración previa al despliegue

**Base nueva:** ejecutar `Persistencia/migraciones/000_esquema_inicial.sql`, que crea las tablas e incluye tres productos de prueba y los cambios del catálogo. No requiere ejecutar después `001_catalogo.sql`. Ver `Persistencia/migraciones/LEEME.md`.

**Base existente:** usar la migración siguiente, conservando las tablas y datos anteriores.

Revisar y ejecutar manualmente Persistencia/migraciones/001_catalogo.sql contra PostgreSQL antes de desplegar esta versión. No se ha ejecutado sobre ninguna base real.

El script agrega producto.clave, asigna LEGACY-<id> a productos antiguos sin clave, exige clave y crea un índice único insensible a mayúsculas y espacios exteriores. También permite imagen_producto.color_id nulo. No cambia los IDs ni elimina registros. Las claves LEGACY pueden sustituirse manualmente por las claves comerciales deseadas. La migración aborta si los datos existentes violan el índice único.

JPA mantiene ddl-auto=none. El código no aplica cambios de esquema automáticamente.

## Rutas REST

Todas requieren autenticación y rol ADMIN o EMPLEADO. Las rutas del diagrama son /api/productos y /api/catalogo; /api/admin/productos y /api/admin/catalogo se conservan como alias compatibles con la implementación anterior y tienen los mismos permisos.

| Método | Ruta | Respuesta |
| --- | --- | --- |
| GET | /api/admin/productos | 200 y lista ProductoCatalogoDTO |
| GET | /api/admin/productos/buscar | 200 y lista filtrada |
| POST | /api/admin/productos | 201 sin cuerpo (multipart con imágenes o JSON con URLs) |
| GET | /api/admin/productos/{idProducto} | 200 y ProductoEdicionDTO (formulario de edición) |
| PUT | /api/admin/productos/{idProducto} | 200 y ProductoEdicionDTO actualizado (multipart con imágenes nuevas o JSON) |
| DELETE | /api/admin/productos/{idProducto} | 200 y ResultadoBajaDTO |
| GET | /api/admin/catalogo/filtros | 200 y FiltrosDisponiblesDTO |
| GET | /api/admin/catalogo/categorias/{idCategoria}/tallas | 200 y lista TallaDTO |

La búsqueda en /api/productos/buscar admite texto, idCategoria, idSubcategoria, idMarca y estado. Exige al menos un filtro no vacío; sin filtros devuelve 400. Para recuperar todos los productos se utiliza GET /api/productos. El texto busca por nombre o clave sin distinguir mayúsculas. Los filtros se combinan. El catálogo administrativo puede mostrar borradores e inactivos; no constituye un catálogo público.

## Alta

El formulario envía multipart: parte `producto` (JSON) y parte `imagenes` (uno o varios archivos). Cada elemento de `producto.imagenes` dice el **color** de la imagen y su origen: `archivo` es la posición del archivo en la parte `imagenes` (0, 1, 2…). El orden de la lista es el orden de la galería: la primera imagen de cada color es la principal de ese color y la primera de todas es la principal del producto. Ver [configuración de Storage](STORAGE.md).

```json
{
  "clave": "NE-940-LAD",
  "nombre": "9FORTY LA Dodgers",
  "descripcion": "Gorra ajustable",
  "idCategoria": "2",
  "idSubcategoria": "3",
  "idMarca": "11",
  "estado": "PUBLICADO",
  "variantes": [
    {"talla": "Ajustable", "color": "Negro", "stock": 10},
    {"talla": "7 1/8", "color": "Negro", "stock": 2},
    {"talla": "Ajustable", "color": "Gris", "stock": 4}
  ],
  "preciosProducto": [
    {"tipoPrecio": "BASE", "precio": 450.00, "minPiezas": 1},
    {"tipoPrecio": "MAYOREO", "precio": 380.00, "minPiezas": 6}
  ],
  "imagenes": [
    {"color": "Negro", "archivo": 0},
    {"color": "Negro", "archivo": 1},
    {"color": "Gris", "archivo": 2}
  ]
}
```

Por compatibilidad, POST también recibe `application/json`; entonces cada imagen va con `url` en lugar de `archivo`: `{"color": "Negro", "url": "https://…/negro.jpg"}`.

Las imágenes son de un **color**, no de una talla: las variantes Negro/Ajustable y Negro/7 1/8 comparten las fotos del color Negro (en la base `imagen_producto` tiene `color_id`, no `variante_id`).

El alta guarda el agregado completo en una transacción. La subcategoría debe pertenecer a la categoría, la marca debe existir y estar activa, y cada nombre de talla/color debe resolverse sin ambigüedad. Se genera un SKU técnico único por variante porque el esquema anterior lo requiere; no es un dato solicitado en el diagrama.

Validaciones: clave/nombre/descripción obligatorios, IDs positivos dentro del rango Long, estados PUBLICADO/BORRADOR/INACTIVO, al menos una variante e imagen, stock no negativo y combinaciones talla/color únicas ignorando mayúsculas y espacios exteriores.

Imágenes: cada imagen indica su color y **un solo** origen (`archivo` o `url`; `idImagen` solo al editar); el color debe ser uno de las variantes; cada color de las variantes tiene al menos una imagen; cada archivo aparece una sola vez en la lista y no sobran archivos; máximo 10 archivos por petición, JPG/PNG/WEBP de hasta 5 MB (el servidor acepta hasta 52 MB por petición; si se excede responde 413). Todo se valida **antes** de subir nada. Si falla una subida, se retiran las ya subidas.

Se requiere al menos un precio, tipos de precio válidos y no repetidos, importes y cantidades mínimos positivos, y BASE desde una pieza. Los precios por volumen no pueden superar BASE. Se preservan los valores de TipoPrecio anteriores. El estado STOCK_BAJO preexistente se conserva en la entidad y puede consultarse, pero no se acepta como nuevo estado de alta según el diagrama.

La clave se valida antes de guardar y el índice único protege también ante altas simultáneas. Los errores de validación devuelven 400, los recursos faltantes 404 y los conflictos de integridad/clave 409.

## Editar producto (CU-03 S1)

**GET /api/productos/{idProducto}** devuelve `ProductoEdicionDTO`: datos, línea, tipo y marca (con id y nombre), estado, precios, variantes (`idVariante`, talla, color, existencia y `conPedidos`) e imágenes (`idImagen`, url, color y orden).

**PUT /api/productos/{idProducto}** recibe `EditarProductoDTO` en JSON o en multipart (`producto` + `imagenes` con los archivos nuevos) y responde el producto actualizado:

```json
{
  "clave": "NE-940-LAD",
  "nombre": "9FORTY LA Dodgers",
  "descripcion": "Gorra ajustable",
  "idSubcategoria": "3",
  "idMarca": "11",
  "estado": "PUBLICADO",
  "variantes": [
    {"idVariante": "40", "stock": 7},
    {"talla": "Ajustable", "color": "Rojo", "stock": 5}
  ],
  "preciosProducto": [{"tipoPrecio": "BASE", "precio": 460.00, "minPiezas": 1}],
  "imagenes": [
    {"idImagen": "55", "color": "Negro"},
    {"archivo": 0, "color": "Rojo"}
  ]
}
```

Reglas:

- **Lo que no se manda se quita** (variantes, imágenes y precios). El orden de `imagenes` es el nuevo orden de la galería.
- La **línea no cambia**: el tipo (subcategoría) debe ser de la misma línea del producto. Clave, nombre, descripción, marca, tipo, estado, precios, variantes e imágenes sí.
- **Variantes:** con `idVariante` solo cambia la existencia (si se manda talla o color deben ser los mismos; para cambiarlos se quita la variante y se agrega otra). Sin `idVariante` es nueva y se valida como en el alta. Una variante quitada que está en un **carrito o pedido** (`conPedidos`) no se borra: se queda con existencia 0. Una variante nueva no puede repetir color y talla de otra que se queda.
- **Imágenes:** `idImagen` conserva una imagen del producto (puede cambiar de color u orden); `archivo` agrega una nueva. Mismas reglas de color que en el alta, contando solo los colores de las variantes que se mandan.
- **Estado:** PUBLICADO, BORRADOR o INACTIVO; STOCK_BAJO solo si el producto ya lo tenía.
- **Clave:** si cambia, no puede ser de otro producto (409).
- Las imágenes quitadas se borran de Storage al confirmar la transacción, solo si ningún otro producto usa esa URL y la subió el backend (ver STORAGE.md).
- El PUT bloquea el producto antes de guardar (como la baja). El GET **no** bloquea: corre en una transacción de solo lectura y PostgreSQL rechaza `SELECT … FOR UPDATE` ahí (error 25006, que se veía como 500 `ERROR_INTERNO`). Errores: 400 datos, 404 producto, 409 clave.
- Variantes guardadas sin talla (borradores importados) se devuelven con `idTalla`/`talla` en `null` y se pueden conservar enviando solo `idVariante` y `stock`.

Negocio valida primero la petición (sin tocar la base), luego las reglas que dependen del producto guardado y al final sube los archivos. Persistencia recibe `CambiosProducto` y resuelve tipo, marca, tallas y colores antes de modificar el producto.

## Relación con la tienda (CU-01)

Como las imágenes quedan ligadas a su color, la tienda puede mostrarlas por color: los cuadritos de color de cada tarjeta llevan la foto de ese color y la ficha filtra la galería por el color elegido. Al **filtrar por color** (`color=…` en `/api/catalogo/{linea}` o `/api/catalogo/buscar`), cada tarjeta abre en el color buscado: `imagenUrl` es la foto de ese color, ese color va primero en `colores` y `idColorDestacado` dice cuál es (es `null` sin filtro de color). El front puede usar `idColorDestacado` para abrir la ficha en ese color (`/producto/{id}?color={idColorDestacado}`).

## Baja

Si existen detalles de venta relacionados con variantes del producto, se cambia su estado a INACTIVO y se devuelve tipoBaja LOGICA. Sin ventas se elimina y se devuelve FISICA. El ID de respuesta es String. La operación bloquea el producto durante la transacción. Una referencia ajena a ventas que impida eliminarlo se informa como conflicto 409; no se eliminan registros históricos para forzar la operación.

## Alcance de las pruebas

Se prueban reglas de alta/baja, filtros e IDs, mapeo del agregado, contratos y validación HTTP, preservación de sesión, seguridad y composición entre proyectos. Imágenes por color y edición: `ImagenesPorColorTest` (orden y color de cada archivo, reglas de color, archivos sobrantes o repetidos, límite de 10, retiro si falla una subida, alta por JSON con URL) y `EditarProductoBOTest` (formulario con `conPedidos`, existencias, variante con pedidos que queda en 0, imágenes conservadas y nuevas, precios, borrado en Storage solo al confirmar y solo de archivos propios sin otro uso, clave repetida, 404 y validaciones antes de consultar la base); `CatalogoControllerTest` cubre GET/PUT y el multipart con varios archivos. Se valida el metamodelo JPA y la interpretación de las consultas HQL sin abrir conexiones. Falta ejecutar la migración y las pruebas de integración contra el esquema PostgreSQL real.

La consulta del frontend está conectada en /admin/catalogo siguiendo el flujo Pantalla → hook → CatalogoModel → servicios HTTP → Controllers → BO → DAO. Se cargan productos y después filtros; la búsqueda vacía se rechaza también en presentación, sin enviar peticiones. Las respuestas antiguas no reemplazan resultados recientes.

El alta del frontend está conectada: Nuevo producto → carga de filtros/tallas → captura y validación → ProductoModel.aCrearProductoDTO → ProductoService → POST /api/productos. Envía la parte `imagenes` (varios archivos) y la lista `producto.imagenes` con el color de cada uno (ver «Alta»); la forma anterior con una sola parte `imagen` responde 400. Se espera 201 sin cuerpo. ProductoBO valida el producto completo antes de consultar duplicados y solo después invoca al mapper y al DAO. Tras el éxito se vuelve al catálogo y se recarga la lista. Un 400 o 409 conserva el formulario para corregirlo.

La baja del frontend está conectada conforme al flujo aprobado: confirmación o cancelación, DELETE /api/productos/{id}, adaptación LOGICA/FISICA y actualización del catálogo conservando filtros. Cancelar no modifica datos; los errores mantienen el diálogo y no muestran éxito. La carga de archivos utiliza Supabase Storage según STORAGE.md. La edición está conectada en el frontend (`/admin/catalogo/{id}/editar`, dentro del panel «Administrar tienda») con GET/PUT /api/productos/{id}. La reactivación sigue fuera del alcance. Las pruebas HTTP del frontend usan respuestas controladas y las del backend usan puertos falsos; no se han insertado productos nuevos en la BD real del usuario durante esta implementación.


La configuración local API/src/main/resources/application.properties contiene la conexión y claves del equipo; está excluida de Git y no es un archivo generado por Maven. Conservarla al limpiar target/. La plantilla application.properties.example sí se versiona.

## Consulta paginada del catálogo administrativo

Enviar `pagina` (desde 0) y `tamano` (1–50, predeterminado 7) a GET /api/productos o GET /api/productos/buscar. La respuesta es PaginaProductosDTO con productos, pagina, tamano y hayMas. En la búsqueda sigue siendo obligatorio al menos un filtro. Sin parámetros de paginación, ambas rutas conservan la respuesta de lista anterior.

ProductoDAO pagina la consulta raíz ordenada por ID y carga las tres colecciones en consultas separadas para esos IDs. Solo se recupera una fila adicional para detectar si existe otra página, sin COUNT global ni joins paginados de colecciones. Negocio recorta esa fila antes de responder. IDs persistidos Long y públicos String. No requiere migración de tablas.
